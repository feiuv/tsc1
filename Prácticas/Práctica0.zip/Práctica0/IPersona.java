public interface IPersona{
	public void caminar();
	public void comer();
	public void programar();
}