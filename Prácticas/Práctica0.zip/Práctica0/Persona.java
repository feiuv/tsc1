public class Persona implements IPersona
{
	public void caminar(){
		System.out.println("Caminando...");
	}
	
	public void comer(){
		System.out.println("Comiendo...");

	}
	
	public void programar(){
		System.out.println("Programando...");

	}
}