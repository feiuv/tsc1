public class Inventario{
	public static void main(String ars[]){
		IPersona p = new Persona();
		p.caminar();
		p.comer();
	}
}