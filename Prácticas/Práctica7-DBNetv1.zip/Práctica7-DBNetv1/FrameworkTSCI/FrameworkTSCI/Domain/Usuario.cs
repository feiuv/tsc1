﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FrameworkTSCI.Domain
{
    public class Usuario
    {
        public int Id { get; set; }
        public String NombreUsuario { get; set; }
        public String Password{ get; set; }
    }
}
