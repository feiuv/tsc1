﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Perro:Entidad
    {
        private String raza;

        public String Raza
        {
            get
            {
                return raza;    
            }
            set
            {
                this.raza = value;
            }
        }


    }
}
