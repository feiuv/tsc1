﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Academico: Persona
    {
        public override void Correr()
        {
            Console.WriteLine("Academico Corriendo...");
        }

        public override void Caminar()
        {
            Console.WriteLine("Academico Caminando...");
        }

        public override void Comer()
        {
            Console.WriteLine("Academico comiendo...");
        }
    }
}
