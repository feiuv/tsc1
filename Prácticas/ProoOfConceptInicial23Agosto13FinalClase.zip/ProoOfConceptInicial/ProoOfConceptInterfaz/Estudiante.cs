﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Estudiante:Persona
    {
        public override void Correr()
        {
            Console.WriteLine("Estudiante Corriendo...");
        }

        public override void Caminar()
        {
            Console.WriteLine("Estudiante Caminando...");
        }

        public override void Comer()
        {
            Console.WriteLine("Estudiante comiendo...");
        }
    }
}
