﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Administrativo:Persona
    {
        public override void Correr()
        {
            Console.WriteLine("Administrativo Corriendo...");
        }

        public override void Caminar()
        {
            Console.WriteLine("Administrativo Caminando...");
        }

        public override void Comer()
        {
            Console.WriteLine("Administrativo comiendo...");
        }

    }
}
