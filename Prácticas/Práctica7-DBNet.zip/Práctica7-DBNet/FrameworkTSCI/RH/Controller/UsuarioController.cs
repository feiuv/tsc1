﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FrameworkTSCI.Base;
using FrameworkTSCI.Domain;
namespace RH.Controller
{
    class UsuarioController:Entity, Controller<Usuario>
    {

        public void Add(Usuario e)
        {
            throw new NotImplementedException();
        }

        public void Delete(Usuario e)
        {
            throw new NotImplementedException();
        }

        public List<Usuario> GetAll()
        {
            throw new NotImplementedException();
        }

        public List<Usuario> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public bool ValidarUsuario(String usuario, String password)
        {
            bool result = false;

            return result;
        }
    }
}
