﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FrameworkTSCI.Base;
using FrameworkTSCI.Domain;

namespace RH.Controller
{
    public class EstudianteController:Controller<Estudiante>
    {

        public void Add(Estudiante e)
        {
            throw new NotImplementedException();
        }

        public void Delete(Estudiante e)
        {
            throw new NotImplementedException();
        }

        public List<Estudiante> GetAll()
        {
            throw new NotImplementedException();
        }

        public List<Estudiante> GetById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
