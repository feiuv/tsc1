﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace FrameworkTSCI.Base
{
    public class TSCIForm : Form
    {
        public TSCIForm()
            : base()
        {


        }

        public bool ValidarTxt()
        {
            bool result = true;
            foreach (Control c in Controls)
            {

                if (c.Text.Trim().Equals(""))
                {
                    result = false;
                    c.Focus();
                    break;
                }
                //result = false;
            }
            return result;
        }

    }
}
