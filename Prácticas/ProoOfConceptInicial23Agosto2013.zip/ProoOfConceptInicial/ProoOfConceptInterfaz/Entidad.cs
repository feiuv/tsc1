﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Entidad
    {
        private int id;

        public int Hash;
        //Segunda forma
        public string Fecha { get; set; }
        
        //Descriptor primer forma
        public int Id
        {
            set
            {
                id = value;
            }
            get
            {
                return id;
            }
        }




        /// <summary>
        /// En Java tracicionalmente.....
        /// </summary>
        /// <param name="id"></param>
        /*public void setId(int id)
        {
            this.id = id;
        }

        public int getId()
        {
            return id;
        }*/
    }
}
