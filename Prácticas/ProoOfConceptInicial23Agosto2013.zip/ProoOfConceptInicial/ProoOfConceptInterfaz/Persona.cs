﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Persona : Entidad,IPersona
    {
        private char genero;
        public char Genero
        {
            set
            {
                genero = value;
            }
            get
            {
                return genero;
            }
        }

        private String nombre;
        public String Nombre
        {
            set
            {
                nombre = value;
            }
            get
            {
                return nombre;
            }
        }

        private int edad;
        public int Edad
        {
            set
            {
                edad = value;
            }
            get
            {
                return edad;
            }
        }

        public Persona(){
        }

        public Persona(int edad, String fecha, char genero, String nombre)
        {
            this.edad = edad;
            Fecha = fecha;
            Genero = genero;
            Nombre = nombre;
        }

        public void Correr()
        {
            Console.WriteLine("Persona Corriendo...");
        }

        public void Caminar()
        {
            Console.WriteLine("Persona Caminando...");
        }

        public void Comer()
        {
            Console.WriteLine("Persona comiendo...");
        }
    }
}
