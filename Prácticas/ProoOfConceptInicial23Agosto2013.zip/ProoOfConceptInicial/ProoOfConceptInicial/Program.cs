﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using ProoOfConceptInterfaz;
namespace ProoOfConceptInicial
{
    class Program
    {
        static void Main(string[] args)
        {
            //1era forma
            Persona prs0 = new Persona();

            prs0.Edad = 10;
            prs0.Fecha = "";
            prs0.Genero = 'M';


            //2da forma
            IPersona prs1 = new Persona
            {
                Edad = 20,
                Fecha = "10/10/2013",
                Genero = 'M',
                Nombre = "Homero"
            };

            IPersona prs2 = new Persona(10, "10/10/2010", 'M', "Luis");

         
            //Lista que acepta de todo
            ArrayList lista = new ArrayList();
            lista.Add(prs0);
            lista.Add(prs1);
            //((Persona)lista[0]).

            Perro p = new Perro();
            p.Raza = "PX";
            
            //Lista especializada
            List<Persona> listaP = new List<Persona>();
            listaP.Add(prs0);
            

            for (int i = 0; i < lista.Count; i++ )
            {
                IPersona perso = (IPersona)lista[i];
                perso.Caminar();
            }



            foreach (Persona value in lista){
                Console.WriteLine(value.Edad);
            }

                //Meter personas a la lista 

                //3ra forma



                Console.WriteLine("Hola...");       
        }
    }
}
