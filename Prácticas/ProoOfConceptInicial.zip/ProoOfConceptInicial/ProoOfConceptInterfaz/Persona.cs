﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public class Persona : Entidad,IPersona
    {
        private String nombre;
        public String Nombre
        {
            set
            {
                nombre = value;
            }
            get
            {
                return nombre;
            }
        }

        private int edad;
        public int Edad
        {
            set
            {
                edad = value;
            }
            get
            {
                return edad;
            }
        }

        public void Correr()
        {
            Console.WriteLine("Persona Corriendo...");
        }

        public void Caminar()
        {
            Console.WriteLine("Persona Caminando...");
        }

        public void Comer()
        {
            Console.WriteLine("Persona comiendo...");
        }
    }
}
