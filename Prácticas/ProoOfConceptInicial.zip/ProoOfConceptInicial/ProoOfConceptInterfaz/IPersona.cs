﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProoOfConceptInterfaz
{
    public interface IPersona {
        void Comer();
        void Caminar();
        void Correr();
    }
}
