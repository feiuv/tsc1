public class Principal{
	public static void main(String ars[]){
		Motor m = new MotorEconomico();
		m.encender();
        	m.acelerar();
        	m.apagar();
 
        	m = new MotorGaston();
        	m.encender();
        	m.acelerar();
        	m.apagar();
 
        	m = new MotorElectricoAdapter() ;
        	m.encender();
        	m.acelerar();
        	m.apagar();
	}
}