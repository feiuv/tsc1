public class MotorGaston extends Motor {
    public MotorGaston(){
        super();
        System.out.println("Creando el motor gaston");
    }
 
    public void encender() {
        System.out.println("encendiendo motor gaston");
    }
 
    public void acelerar() {
        System.out.println("acelerando!!");
    }
 
    public void apagar() {
        System.out.println("Apagando motor gaston");
	System.out.println("*******************************");
    }
 
}