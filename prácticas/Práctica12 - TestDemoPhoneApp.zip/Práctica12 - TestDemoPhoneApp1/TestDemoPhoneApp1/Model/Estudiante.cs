﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDemoPhoneApp1.Model
{
    public class Estudiante
    {
        public string apellidomaterno { get; set; }
        public string apellidopaterno { get; set; }
        public int edad { get; set; }
        public string id { get; set; }
        public string nombre { get; set; }
    }
}
